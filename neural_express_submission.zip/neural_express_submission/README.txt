The algorithm used by us follows the step for NLP regression problems

Step 1 - We start with identification of missing values and fill them

Step 2 - A distribution of the target variable was identified as skewed with kde plot

Step 3 - Skewness was removed with np log1p

Step 4 - Stopwords and punctuations are removed

Step 5 - Stemming is performed

Step 6 - Count Vectorizer and  TFIDF transformers were used

Step 7 - transformers and Random Forest Regressor were pipelined and trained